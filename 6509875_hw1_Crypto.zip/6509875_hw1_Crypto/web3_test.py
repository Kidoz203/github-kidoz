from web3 import Web3

# Connect to Local Geth Node
w3_geth = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))
print("Geth Connected:", w3_geth.is_connected())
print("Latest Block:", w3_geth.eth.block_number)

# Connect to Infura
infura_URL = 'https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558'
w3_infura = Web3(Web3.HTTPProvider(infura_URL))
print("Infura Connected:", w3_infura.is_connected())
print("Latest Infura Block:", w3_infura.eth.block_number)

# Connect to Tatum
API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
tatum_URL = f'https://api.tatum.io/v3/blockchain/node/ethereum-sepolia/{API_KEY}'
w3_tatum = Web3(Web3.HTTPProvider(tatum_URL))
print("Tatum Connected:", w3_tatum.is_connected())
