from web3 import Web3

# Connect to Infura Sepolia
infura_URL = 'https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558'
w3 = Web3(Web3.HTTPProvider(infura_URL))

# Replace with your account details
sender_address = '0x315ABeBe78c6Fadbc3C410D44D1c8ac0811245E0'
sender_private_key = '375198db5d3db7272747a93311cee8db16096ff8414b015487bb5313751f2495'
receiver_address = '0x4eAdAa00eA1e95A75635f1AB96e26aEbf78bc92a'

# Ensure connection is successful
if not w3.is_connected():
    print("Failed to connect to Infura!")
    exit()

# Create transaction
nonce = w3.eth.get_transaction_count(sender_address)
tx = {
    'to': receiver_address,
    'value': w3.to_wei(0.001, 'ether'),
    'gas': 21000,
    'gasPrice': w3.eth.gas_price,
    'nonce': nonce,
    'chainId': 11155111,  # Sepolia Chain ID
}

# Sign and Send Transaction
signed_tx = w3.eth.account.sign_transaction(tx, sender_private_key)

# Correct the attribute name to `raw_transaction`
tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)

print("Transaction Hash:", tx_hash.hex())
