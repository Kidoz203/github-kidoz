import requests
from pprint import pprint

def json_rpc(url, method='web3_clientVersion'):
    DATA = '{"jsonrpc":"2.0", "method": "%s", "params": [], "id": 1}' % method
    HEADERS = {'Content-type': 'application/json'}
    
    # Send the request and get the response
    response = requests.post(url, data=DATA, headers=HEADERS)
    
    # Print the raw response to debug the issue
    print(f"Raw response from {url}: {response.text}")  # Print raw response
    
    try:
        # Attempt to parse the response as JSON
        return response.json()
    except ValueError:
        print(f"Failed to parse JSON response from {url}.")
        return None  # Return None if the response is not valid JSON

# Geth Local Node
geth_URL = 'http://127.0.0.1:8545'
pprint(json_rpc(geth_URL, 'eth_blockNumber'))  # Get latest block number

# Sepolia Testnet (Alternative)
sepolia_URL = 'https://rpc2.sepolia.org'
pprint(json_rpc(sepolia_URL, 'eth_blockNumber'))

# Infura API (Replace with your own API key)
infura_URL = 'https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558'
pprint(json_rpc(infura_URL, 'eth_blockNumber'))
